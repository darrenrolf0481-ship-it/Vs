import { useState, useRef, useEffect, useCallback } from 'react';
import { useAppStore } from '@/store';
import type { TerminalLine, TerminalSession } from '@/types';
import { executeCommand, getCompletions } from '@/lib/terminal-commands';
import { processClaudeInput, streamText } from '@/lib/claude-repl';
import { X, Plus, Bot, Terminal as TerminalIcon } from 'lucide-react';

function TerminalPrompt({
  session,
  onSubmit,
  disabled,
}: {
  session: TerminalSession;
  onSubmit: (input: string) => void;
  disabled: boolean;
}) {
  const [input, setInput] = useState('');
  const [historyIndex, setHistoryIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const store = useAppStore();

  useEffect(() => {
    if (!disabled) {
      inputRef.current?.focus();
    }
  }, [disabled, session.id]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || disabled) return;
    onSubmit(input);
    store.addToCommandHistory(input);
    setInput('');
    setHistoryIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Tab completion
    if (e.key === 'Tab') {
      e.preventDefault();
      const completions = getCompletions(input, {
        currentPath: session.currentPath,
        fileTree: store.fileTree,
        updateFileTree: () => {},
        getNodePath: () => '',
      });
      if (completions.length === 1) {
        const parts = input.split(/\s+/);
        parts[parts.length - 1] = completions[0];
        setInput(parts.join(' '));
      }
      return;
    }

    // History navigation
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      const history = store.commandHistory;
      if (history.length === 0) return;
      const newIndex = historyIndex + 1;
      if (newIndex < history.length) {
        setHistoryIndex(newIndex);
        setInput(history[history.length - 1 - newIndex]);
      }
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex <= 0) {
        setHistoryIndex(-1);
        setInput('');
        return;
      }
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setInput(store.commandHistory[store.commandHistory.length - 1 - newIndex]);
      return;
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      {session.claudeMode ? (
        <span className="claude-prompt">
          <Bot size={14} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 4 }} />
          claude&gt;
        </span>
      ) : (
        <span className="terminal-prompt">
          user@vscode:{session.currentPath}$
        </span>
      )}
      <input
        ref={inputRef}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        style={{
          background: 'transparent',
          border: 'none',
          color: session.claudeMode ? '#e0d0f0' : '#cccccc',
          fontFamily: "'Consolas', 'Monaco', 'Courier New', monospace",
          fontSize: 13,
          outline: 'none',
          flex: 1,
          caretColor: session.claudeMode ? '#d4a5ff' : '#cccccc',
        }}
        spellCheck={false}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="off"
      />
    </form>
  );
}

function TerminalLineItem({ line }: { line: TerminalLine }) {
  switch (line.type) {
    case 'input':
      return (
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className="terminal-prompt">$</span>
          <span className="terminal-output">{line.content}</span>
        </div>
      );
    case 'output':
      return <div className="terminal-output">{line.content}</div>;
    case 'error':
      return <div className="terminal-error">{line.content}</div>;
    case 'claude-input':
      return (
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <Bot size={14} color="#d4a5ff" />
          <span className="claude-prompt">&gt;</span>
          <span className="claude-output">{line.content}</span>
        </div>
      );
    case 'claude-output':
      return <div className="claude-output" style={{ paddingLeft: 20 }}>{line.content}</div>;
    case 'tool-call':
      return (
        <div
          style={{
            margin: '4px 0 4px 20px',
            padding: '6px 10px',
            background: '#1a1a2e',
            border: '1px solid #2d2d44',
            borderRadius: 4,
            fontSize: 12,
            fontFamily: "'Consolas', 'Monaco', 'Courier New', monospace",
          }}
        >
          <div style={{ color: '#d4a5ff', display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 10 }}>▶</span>
            <span>Tool call: {line.content}</span>
          </div>
        </div>
      );
    default:
      return <div className="terminal-output">{line.content}</div>;
  }
}

export function TerminalPanel() {
  const {
    terminalSessions,
    activeTerminalId,
    switchTerminal,
    createTerminalSession,
    closeTerminal,
    addTerminalLine,
    setTerminalPath,
    toggleClaudeMode,
    fileTree,
  } = useAppStore();

  const [streaming, setStreaming] = useState(false);
  const [activeTab, setActiveTab] = useState<'terminal' | 'problems' | 'output' | 'debug-console'>('terminal');
  const scrollRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when history changes
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [terminalSessions, activeTerminalId]);

  const handleCommand = useCallback(
    (input: string) => {
      const session = terminalSessions.find((s) => s.id === activeTerminalId);
      if (!session) return;

      // In Claude mode
      if (session.claudeMode) {
        // Add user input line
        addTerminalLine(session.id, {
          type: 'claude-input',
          content: input,
          timestamp: Date.now(),
        });

        const result = processClaudeInput(input);

        if (result.type === 'exit') {
          toggleClaudeMode(session.id);
          addTerminalLine(session.id, {
            type: 'output',
            content: 'Exited Claude Code REPL. Type \'claude\' to enter again.',
            timestamp: Date.now(),
          });
          return;
        }

        if (result.type === 'clear') {
          useAppStore.setState((state) => ({
            terminalSessions: state.terminalSessions.map((s) =>
              s.id === session.id ? { ...s, history: [] } : s
            ),
          }));
          return;
        }

        if (result.content) {
          setStreaming(true);
          let streamedContent = '';

          streamText(
            result.content,
            (chunk) => {
              streamedContent += chunk;
              // Update the last line in real-time
              useAppStore.setState((state) => ({
                terminalSessions: state.terminalSessions.map((s) => {
                  if (s.id !== session.id) return s;
                  const history = [...s.history];
                  const lastIndex = history.length - 1;
                  if (lastIndex >= 0 && history[lastIndex].type === 'claude-output') {
                    history[lastIndex] = { ...history[lastIndex], content: streamedContent };
                  } else {
                    history.push({
                      type: 'claude-output',
                      content: streamedContent,
                      timestamp: Date.now(),
                    });
                  }
                  return { ...s, history };
                }),
              }));
            },
            () => {
              setStreaming(false);
              // Add tool calls after stream completes
              if (result.tools) {
                for (const tool of result.tools) {
                  addTerminalLine(session.id, {
                    type: 'tool-call',
                    content: `${tool.name}(${JSON.stringify(tool.input)}) ✓ ${tool.output}`,
                    timestamp: Date.now(),
                  });
                }
              }
            }
          );
        }
        return;
      }

      // Normal terminal mode
      addTerminalLine(session.id, {
        type: 'input',
        content: input,
        timestamp: Date.now(),
      });

      // Check for claude command
      if (input.trim() === 'claude') {
        toggleClaudeMode(session.id);
        addTerminalLine(session.id, {
          type: 'claude-output',
          content: `Claude Code REPL initialized.
Type /help for available commands or ask me anything!`,
          timestamp: Date.now(),
        });
        return;
      }

      // Execute command
      const result = executeCommand(input, {
        currentPath: session.currentPath,
        fileTree,
        updateFileTree: (tree) => useAppStore.setState({ fileTree: tree }),
        getNodePath: () => '',
      });

      if (result.output === '__CLEAR__') {
        useAppStore.setState((state) => ({
          terminalSessions: state.terminalSessions.map((s) =>
            s.id === session.id ? { ...s, history: [] } : s
          ),
        }));
        return;
      }

      if (result.output) {
        addTerminalLine(session.id, {
          type: result.error ? 'error' : 'output',
          content: result.output,
          timestamp: Date.now(),
        });
      }

      if (result.newPath) {
        setTerminalPath(session.id, result.newPath);
      }
    },
    [activeTerminalId, terminalSessions, fileTree, addTerminalLine, setTerminalPath, toggleClaudeMode]
  );

  const activeSession = terminalSessions.find((s) => s.id === activeTerminalId);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Panel Tabs */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        background: '#252526',
        borderBottom: '1px solid #3e3e42',
        height: 35,
        paddingLeft: 8,
      }}>
        {[
          { id: 'terminal' as const, label: 'Terminal', icon: TerminalIcon },
          { id: 'problems' as const, label: 'Problems', icon: null },
          { id: 'output' as const, label: 'Output', icon: null },
          { id: 'debug-console' as const, label: 'Debug Console', icon: null },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              background: activeTab === tab.id ? '#1e1e1e' : 'transparent',
              border: 'none',
              borderTop: activeTab === tab.id ? '1px solid #007acc' : '1px solid transparent',
              color: activeTab === tab.id ? '#cccccc' : '#858585',
              fontSize: 12,
              padding: '0 12px',
              height: '100%',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 4,
            }}
          >
            {tab.icon && <tab.icon size={14} />}
            {tab.label}
          </button>
        ))}

        <div style={{ marginLeft: 'auto', display: 'flex', gap: 2, paddingRight: 8 }}>
          {/* Terminal session tabs */}
          {terminalSessions.map((s) => (
            <button
              key={s.id}
              onClick={() => switchTerminal(s.id)}
              style={{
                background: s.id === activeTerminalId ? '#1e1e1e' : 'transparent',
                border: 'none',
                color: s.id === activeTerminalId ? '#cccccc' : '#858585',
                fontSize: 11,
                padding: '2px 8px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                borderRadius: 3,
              }}
            >
              {s.claudeMode ? <Bot size={12} color="#d4a5ff" /> : <TerminalIcon size={12} />}
              {s.name}
              <span
                onClick={(e) => { e.stopPropagation(); closeTerminal(s.id); }}
                style={{ cursor: 'pointer', padding: '0 2px' }}
              >
                <X size={10} />
              </span>
            </button>
          ))}

          <button
            onClick={createTerminalSession}
            title="New Terminal"
            style={{
              background: 'transparent',
              border: 'none',
              color: '#858585',
              cursor: 'pointer',
              padding: '2px 6px',
            }}
          >
            <Plus size={14} />
          </button>
        </div>
      </div>

      {/* Terminal Content */}
      {activeTab === 'terminal' && activeSession && (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div
            ref={scrollRef}
            className="scrollbars"
            style={{
              flex: 1,
              overflow: 'auto',
              padding: '8px 12px',
              background: activeSession.claudeMode ? '#0d0d1a' : '#1e1e1e',
            }}
          >
            {activeSession.history.map((line, i) => (
              <TerminalLineItem key={`${activeSession.id}-${i}`} line={line} />
            ))}
          </div>

          {/* Input */}
          <div style={{
            padding: '6px 12px',
            borderTop: '1px solid #3e3e42',
            background: activeSession.claudeMode ? '#0d0d1a' : '#1e1e1e',
          }}>
            <TerminalPrompt
              session={activeSession}
              onSubmit={handleCommand}
              disabled={streaming}
            />
          </div>
        </div>
      )}

      {activeTab === 'problems' && (
        <div style={{ flex: 1, padding: 12, color: '#858585', fontSize: 13 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <span style={{ color: '#f48771' }}>●</span>
            <span>src/app.ts:10 — Type 'string' is not assignable to type 'number'</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ color: '#cca700' }}>●</span>
            <span>src/index.ts:4 — 'app' is declared but its value is never read</span>
          </div>
        </div>
      )}

      {activeTab === 'output' && (
        <div style={{ flex: 1, padding: 12, color: '#858585', fontSize: 13 }}>
          [info] Extension host started
          {'\n'}[info] TypeScript language service initialized
          {'\n'}[info] ESLint server running in node v20.12.0
        </div>
      )}

      {activeTab === 'debug-console' && (
        <div style={{ flex: 1, padding: 12, color: '#858585', fontSize: 13 }}>
          Debug console ready. Start debugging to see output.
        </div>
      )}
    </div>
  );
}
