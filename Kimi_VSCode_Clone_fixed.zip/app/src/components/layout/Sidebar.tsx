import { useAppStore } from '@/store';
import { ExplorerView } from '@/components/sidebar/ExplorerView';
import { SearchView } from '@/components/sidebar/SearchView';
import { SCMView } from '@/components/sidebar/SCMView';
import { DebugView } from '@/components/sidebar/DebugView';
import { ExtensionsView } from '@/components/sidebar/ExtensionsView';

export function Sidebar() {
  const { sidebarVisible, sidebarView, sidebarWidth, setSidebarWidth } = useAppStore();

  if (!sidebarVisible) return null;

  const renderView = () => {
    switch (sidebarView) {
      case 'explorer': return <ExplorerView />;
      case 'search': return <SearchView />;
      case 'scm': return <SCMView />;
      case 'debug': return <DebugView />;
      case 'extensions': return <ExtensionsView />;
    }
  };

  return (
    <>
      <div className="vscode-sidebar scrollbars" style={{ width: sidebarWidth, minWidth: 150 }}>
        {renderView()}
      </div>
      {/* Resize Handle */}
      <div
        className="resize-handle-v"
        onMouseDown={(e) => {
          const startX = e.clientX;
          const startWidth = sidebarWidth;

          function handleMouseMove(e: MouseEvent) {
            const newWidth = startWidth + (e.clientX - startX);
            setSidebarWidth(newWidth);
          }

          function handleMouseUp() {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
          }

          document.addEventListener('mousemove', handleMouseMove);
          document.addEventListener('mouseup', handleMouseUp);
          document.body.style.cursor = 'col-resize';
          document.body.style.userSelect = 'none';
        }}
      />
    </>
  );
}
