import { useAppStore } from '@/store';
import { X, FileCode } from 'lucide-react';

export function TabBar() {
  const { editorTabs, activeTabId, setActiveTab, closeTab, closeOtherTabs, closeAllTabs } = useAppStore();

  if (editorTabs.length === 0) return null;

  return (
    <div style={{
      display: 'flex',
      background: '#252526',
      height: 35,
      overflowX: 'auto',
      overflowY: 'hidden',
    }}>
      {editorTabs.map((tab) => {
        const isActive = tab.id === activeTabId;
        return (
          <div
            key={tab.id}
            className={`vscode-tab ${isActive ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
            onContextMenu={(e) => {
              e.preventDefault();
              const menu = document.createElement('div');
              menu.className = 'context-menu';
              menu.style.left = `${e.clientX}px`;
              menu.style.top = `${e.clientY}px`;

              const items = [
                { label: 'Close', action: () => { closeTab(tab.id); menu.remove(); } },
                { label: 'Close Others', action: () => { closeOtherTabs(tab.id); menu.remove(); } },
                { label: 'Close All', action: () => { closeAllTabs(); menu.remove(); } },
              ];

              items.forEach((item) => {
                const div = document.createElement('div');
                div.className = 'context-menu-item';
                div.textContent = item.label;
                div.onclick = item.action;
                menu.appendChild(div);
              });

              document.body.appendChild(menu);
              const closeMenu = () => { menu.remove(); document.removeEventListener('mousedown', closeMenu); };
              setTimeout(() => document.addEventListener('mousedown', closeMenu), 0);
            }}
          >
            <FileCode size={14} color={isActive ? '#519aba' : '#858585'} />
            <span style={{ marginLeft: 4 }}>{tab.name}</span>
            {tab.modified && <span style={{ color: '#cccccc', marginLeft: 2 }}>●</span>}
            <button
              style={{
                marginLeft: 6,
                background: 'transparent',
                border: 'none',
                color: '#858585',
                cursor: 'pointer',
                padding: 1,
                display: 'flex',
                alignItems: 'center',
                borderRadius: 3,
              }}
              onClick={(e) => {
                e.stopPropagation();
                closeTab(tab.id);
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.background = '#3e3e42';
                (e.currentTarget as HTMLButtonElement).style.color = '#cccccc';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.background = 'transparent';
                (e.currentTarget as HTMLButtonElement).style.color = '#858585';
              }}
            >
              <X size={12} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
