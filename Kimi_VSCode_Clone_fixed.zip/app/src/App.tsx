import { useEffect, useCallback } from 'react';
import { useAppStore } from '@/store';
import { TitleBar } from '@/components/layout/TitleBar';
import { ActivityBar } from '@/components/layout/ActivityBar';
import { Sidebar } from '@/components/layout/Sidebar';
import { EditorArea } from '@/components/editor/EditorArea';
import { TerminalPanel } from '@/components/terminal/Terminal';
import { StatusBar } from '@/components/layout/StatusBar';
import './App.css';

function App() {
  const {
    panelVisible,
    panelHeight,
    togglePanel,
    toggleSidebar,
    loadState,
    editorTabs,
    closeTab,
    setActiveTab,
    setSidebarView,
    createFile,
    createTerminalSession,
  } = useAppStore();

  // Load persisted state on mount
  useEffect(() => {
    loadState();
  }, [loadState]);

  // Global keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+N: New File
      if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        createFile('root-src', 'untitled.ts');
      }

      // Ctrl+W: Close active tab
      if (e.ctrlKey && e.key === 'w') {
        e.preventDefault();
        const state = useAppStore.getState();
        if (state.activeTabId) {
          closeTab(state.activeTabId);
        }
      }

      // Ctrl+`: Toggle terminal
      if (e.ctrlKey && e.key === '`') {
        e.preventDefault();
        togglePanel();
      }

      // Ctrl+B: Toggle sidebar
      if (e.ctrlKey && e.key === 'b') {
        e.preventDefault();
        toggleSidebar();
      }

      // Ctrl+Shift+E: Explorer
      if (e.ctrlKey && e.shiftKey && e.key === 'E') {
        e.preventDefault();
        setSidebarView('explorer');
      }

      // Ctrl+Shift+F: Search
      if (e.ctrlKey && e.shiftKey && e.key === 'F') {
        e.preventDefault();
        setSidebarView('search');
      }

      // Ctrl+Shift+G: Source Control
      if (e.ctrlKey && e.shiftKey && e.key === 'G') {
        e.preventDefault();
        setSidebarView('scm');
      }

      // Ctrl+Shift+D: Debug
      if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        e.preventDefault();
        setSidebarView('debug');
      }

      // Ctrl+Shift+X: Extensions
      if (e.ctrlKey && e.shiftKey && e.key === 'X') {
        e.preventDefault();
        setSidebarView('extensions');
      }

      // Ctrl+Shift+`: New Terminal
      if (e.ctrlKey && e.shiftKey && e.key === '`') {
        e.preventDefault();
        createTerminalSession();
        const state = useAppStore.getState();
        if (!state.panelVisible) state.togglePanel();
      }

      // Ctrl+1/2/3: Focus tab
      if (e.ctrlKey && e.key >= '1' && e.key <= '9') {
        e.preventDefault();
        const index = parseInt(e.key) - 1;
        if (editorTabs[index]) {
          setActiveTab(editorTabs[index].id);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePanel, toggleSidebar, closeTab, setActiveTab, setSidebarView, createFile, createTerminalSession, editorTabs]);

  // Handle resize for panel
  const handlePanelResize = useCallback((e: React.MouseEvent) => {
    const startY = e.clientY;
    const startHeight = panelHeight;

    function handleMouseMove(e: MouseEvent) {
      const newHeight = startHeight - (e.clientY - startY);
      useAppStore.getState().setPanelHeight(newHeight);
    }

    function handleMouseUp() {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';
  }, [panelHeight]);

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
      width: '100vw',
      overflow: 'hidden',
      background: '#1e1e1e',
    }}>
      {/* Title Bar */}
      <TitleBar />

      {/* Main Content */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Activity Bar */}
        <ActivityBar />

        {/* Sidebar */}
        <Sidebar />

        {/* Editor + Panel */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {/* Editor */}
          <div style={{ flex: 1, overflow: 'hidden' }}>
            <EditorArea />
          </div>

          {/* Panel Resize Handle */}
          {panelVisible && (
            <div
              className="resize-handle-h"
              onMouseDown={handlePanelResize}
              style={{
                cursor: 'row-resize',
                height: 4,
                background: 'transparent',
                transition: 'background 0.15s ease',
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.background = '#007acc'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.background = 'transparent'; }}
            />
          )}

          {/* Terminal Panel */}
          {panelVisible && (
            <div style={{ height: panelHeight, minHeight: 100, overflow: 'hidden' }}>
              <TerminalPanel />
            </div>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <StatusBar />
    </div>
  );
}

export default App;
